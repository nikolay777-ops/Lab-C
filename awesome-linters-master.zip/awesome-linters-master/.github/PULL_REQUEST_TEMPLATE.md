<!-- Write anything you wish or feel is necessary above this comment. -->

**Information:**

- Language:
- Linter:
- URL:

<!-- Please tick all the boxes below if you fulfilled them. -->

**Checklist:**

- [ ] Only added one linter?
- [ ] Is it inside the right language container?
- [ ] Is it sorted alphabetically inside the container?
- [ ] Does the title follow the template: "Add [LINTER] for [LANGUAGE]."?

For reference, there's some [contributing guidelines](/CONTRIBUTING.md).

<!-- Thank you for helping out! -->
